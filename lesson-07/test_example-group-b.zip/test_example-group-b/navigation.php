<ul class="nav nav-tabs">
  <li><a href="new_product.php">New product</a></li>
  <li><a href="products.php">products</a></li>
</ul>