<ul class="nav nav-tabs">
  <li><a href="new_user.php">New User</a></li>
  <li><a href="users.php">Users</a></li>
</ul>