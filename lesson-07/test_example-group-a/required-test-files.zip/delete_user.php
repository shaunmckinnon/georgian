<?php

  /* VALIDATION */
  session_start();

  /* Step 1 - Create a flag variable to monitor validation state and an error message variable to hold the error messages */

  /* Step 2 - Assign the variable from the $_POST associative array */

  /* Step 3 - Check if the required fields (user_id) are empty */

  /* Step 4 - Check the state of the validation flag and redirect the user with an error message if needed */
  /* HINT: don't forget to exit */

  /* Step 5 - Connect to the database */

  /* Step 6 - Build a SQL string to delete the record in the table term1_users based on the user_id */

  /* Step 7 - Prepare the SQL statement */

  /* Step 8 - Bind the values to the placeholders in the SQL statment */

  /* Step 9 - Execute the SQL statement */

  /* Step 10 - Close the connection */

  /* Step 11 - Redirect the user to the confirmed.php page with a success message */
  /* HINT: don't forget to exit */